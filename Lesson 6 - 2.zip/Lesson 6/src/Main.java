import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        createUsersFile();
        createTasksFile();

        Scanner scanner = new Scanner(System.in);
        LoginUser login = new LoginUser("users.txt");

        try {
            System.out.print("Enter username: ");
            String username = scanner.nextLine();

            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            User user = login.authenticate(username, password);

            if (user.getRole().equals("admin")) {
                AdminMenu adminMenu = new AdminMenu();

                while (true) {
                    System.out.println("\n--- Admin Menu ---");
                    System.out.println("1. Add user");
                    System.out.println("2. Delete user");
                    System.out.println("3. Assign task");
                    System.out.println("4. View all tasks");
                    System.out.println("5. Exit");

                    System.out.print("Choose option: ");
                    String choice = scanner.nextLine();

                    switch (choice) {
                        case "1":
                            adminMenu.addUser();
                            break;
                        case "2":
                            adminMenu.deleteUser();
                            break;
                        case "3":
                            adminMenu.assignTask();
                            break;
                        case "4":
                            adminMenu.viewAllTasks();
                            break;
                        case "5":
                            System.out.println("Exiting system...");
                            return;
                        default:
                            System.out.println("Invalid option.");
                    }
                }
            } else if (user.getRole().equals("member")) {
                MemberMenu memberMenu = new MemberMenu(user.getUserName());

                while (true) {
                    System.out.println("\n--- Member Menu ---");
                    System.out.println("1. View my tasks");
                    System.out.println("2. Mark task as completed");
                    System.out.println("3. Add progress note");
                    System.out.println("4. Exit");

                    System.out.print("Choose option: ");
                    String choice = scanner.nextLine();

                    switch (choice) {
                        case "1":
                            memberMenu.viewMyTasks();
                            break;
                        case "2":
                            memberMenu.markTaskAsCompleted();
                            break;
                        case "3":
                            memberMenu.addProgressNote();
                            break;
                        case "4":
                            System.out.println("Exiting system...");
                            return;
                        default:
                            System.out.println("Invalid option.");
                    }
                }
            } else {
                System.out.println("Invalid role.");
            }

        } catch (InvalidCredentialsException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void createUsersFile() {
        File file = new File("users.txt");

        if (!file.exists()) {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write("admin1,1234,admin\n");
                writer.write("member1,abcd,member\n");
                writer.write("member2,pass,member\n");
                System.out.println("users.txt file created successfully.");
            } catch (IOException e) {
                System.out.println("Error creating users.txt: " + e.getMessage());
            }
        } else {
            System.out.println("users.txt file already exists.");
        }
    }

    public static void createTasksFile() {
        File file = new File("tasks.txt");
        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("tasks.txt file created successfully.");
                }
            } catch (IOException e) {
                System.out.println("Error creating tasks.txt: " + e.getMessage());
            }
        } else {
            System.out.println("tasks.txt file already exists.");
        }
    }


}
