import java.io.*;
import java.util.List;
import java.util.Scanner;

public class AdminMenu {

    private final Scanner scanner = new Scanner(System.in);
    private final String usersFilePath = "users.txt";
    private final String tasksFilePath = "tasks.txt";

    public void showMenu () {

        while (true) {

            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Add new user");
            System.out.println("2. Delete user");
            System.out.println("3. Assign task to user");
            System.out.println("4. View all tasks");
            System.out.println("5. Exit");

            System.out.println("Choose an option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1": addUser(); break;
                case "2": deleteUser(); break;
                case "3": assignTask(); break;
                case "4": viewAllTasks(); break;
                case "5": return;
                default: System.out.println("Invalid choice");

            }
        }
    }

    public void addUser() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter role (admin/member): ");
        String role = scanner.nextLine();

        if (!role.equals("admin") && !role.equals("member")) {
            System.out.println("Role must be either 'admin' or 'member'.");
            return;
        }

        String newUserLine = username + "," + password + "," + role;

        FileHandle.writeLine(usersFilePath, newUserLine, true);
        System.out.println("User added successfully...");
    }

    public void deleteUser() {
        System.out.print("Enter username to delete: ");
        String usernameToDelete = scanner.nextLine().trim();
        File inputFile = new File(usersFilePath);
        File tempFile = new File("users_temp.txt");

        FileHandle.deleteUser(inputFile, tempFile, usernameToDelete);
    }


    public void assignTask() {
        System.out.print("Enter task ID: ");
        String taskId = scanner.nextLine().trim();
        System.out.print("Assign to (username): ");
        String assignedTo = scanner.nextLine().trim();
        System.out.print("Task description: ");
        String description = scanner.nextLine().trim();
        System.out.print("Deadline (e.g. 2025-06-01): ");
        String deadline = scanner.nextLine().trim();

        String taskLine = taskId + "," + assignedTo + "," + description + "," + deadline + ",false";

        FileHandle.writeLine(tasksFilePath, taskLine, true);
        System.out.println("Task assigned.");
    }


    public void viewAllTasks() {
        List<String> lines = FileHandle.readAllLines(tasksFilePath);
        System.out.println("\n--- All Tasks ---");

        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length == 5) {
                System.out.println("ID: " + parts[0] + " | User: " + parts[1] + " | Desc: " + parts[2] +
                        " | Deadline: " + parts[3] + " | Done: " + parts[4]);
            }
        }
    }


}
