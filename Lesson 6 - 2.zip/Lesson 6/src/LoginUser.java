import java.util.ArrayList;
import java.util.List;

public class LoginUser {

    private List<User> users;

    public LoginUser(String filePath) {
        this.users = loadUsers(filePath);
    }

    private List<User> loadUsers(String filePath) {
        List<User> userList = new ArrayList<>();
        List<String> lines = FileHandle.readAllLines(filePath);

        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length == 3) {
                userList.add(new User(parts[0].trim(), parts[1].trim(), parts[2].trim()));
            }
        }

        return userList;
    }

    public User authenticate(String username, String password) throws InvalidCredentialsException {
        for (User user : users) {
            if (user.getUserName().equalsIgnoreCase(username) && user.getPassword().equals(password)) {
                System.out.println("Login successful!");
                return user;
            }
        }
        throw new InvalidCredentialsException("Username or password is incorrect.");
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }
}
