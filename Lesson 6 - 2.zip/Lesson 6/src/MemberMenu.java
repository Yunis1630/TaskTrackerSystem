import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class MemberMenu {

    private final String usersFilePath = "users.txt";
    private final String tasksFilePath = "tasks.txt";

    private String username;
    private Scanner scanner = new Scanner(System.in);

    public MemberMenu(String username) {
        this.username = username;
    }

    public void viewMyTasks() {
        List<String> myTasks = FileHandle.readTasks("tasks.txt", username);

        for (String task : myTasks) {
            String[] parts = task.split(",");
            System.out.println("Task ID: " + parts[0].trim());
            System.out.println("Description: " + parts[2].trim());
            System.out.println("Deadline: " + parts[3].trim());
            System.out.println("Completed: " + parts[4].trim());
        }
    }


    public void markTaskAsCompleted() {
        System.out.print("Enter Task ID to mark as completed: ");
        String taskIdToMark = scanner.nextLine().trim();

        boolean success = FileHandle.updateLine(tasksFilePath, "tasks_temp.txt", taskIdToMark, username);

        if (success) {
            System.out.println("Task marked as completed.");
        } else {
            System.out.println("Task ID not found or not assigned to you.");
        }
    }


    public void addProgressNote() {
        System.out.print("Enter progress note: ");
        String note = scanner.nextLine().trim();

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        String fileName = "progress_" + username + ".txt";
        String lineToWrite = now.format(formatter) + " - " + note;

        FileHandle.writeLine(fileName, lineToWrite, true);

        System.out.println("Progress note saved.");
    }

}
