import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileHandle {

    public static Scanner scanner = new Scanner(System.in);

    public static void writeLine(String filePath, String line, boolean append) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, append))) {
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error writing line: " + e.getMessage());
        }
    }

    public static List<String> readAllLines(String filePath) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return lines;
    }

    public static void deleteUser(File inputFile, File tempFile, String usernameToDelete) {
        try (
                BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))
        ) {
            String line;
            boolean found = false;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3 && !parts[0].trim().equals(usernameToDelete)) {
                    writer.write(line);
                    writer.newLine();
                } else if (parts[0].trim().equals(usernameToDelete)) {
                    found = true;
                }
            }

            if (found) {
                if (inputFile.delete() && tempFile.renameTo(inputFile)) {
                    System.out.println("User deleted successfully.");
                } else {
                    System.out.println("Could not update users file.");
                }
            } else {
                tempFile.delete();
                System.out.println("User not found.");
            }
        } catch (IOException e) {
            System.out.println("Error processing users file.");
        }
    }


    public static void viewTasksForUser(String filePath, String username) {
        List<String> lines = readAllLines(filePath);
        boolean found = false;

        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length == 5 && parts[1].trim().equals(username)) {
                System.out.println("Task ID: " + parts[0].trim());
                System.out.println("Description: " + parts[2].trim());
                System.out.println("Deadline: " + parts[3].trim());
                System.out.println("Completed: " + parts[4].trim());
                System.out.println("--------------");
                found = true;
            }
        }

        if (!found) {
            System.out.println("You have no assigned tasks.");
        }
    }

    public static List<String> readTasks(String filePath, String username) {
        List<String> result = new ArrayList<>();
        List<String> allLines = readAllLines(filePath);

        for (String line : allLines) {
            String[] parts = line.split(",");
            if (parts.length == 5 && parts[1].trim().equals(username)) {
                result.add(line);
            }
        }

        return result;
    }


    public static boolean updateLine(String inputPath, String tempPath, String taskIdToMark, String username) {
        File inputFile = new File(inputPath);
        File tempFile = new File(tempPath);
        boolean updated = false;

        try (
                BufferedReader reader = new BufferedReader(new FileReader(inputFile));
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))
        ) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5 && parts[0].trim().equals(taskIdToMark) && parts[1].trim().equals(username)) {
                    parts[4] = "true";
                    updated = true;
                    line = String.join(",", parts);
                }
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error updating file: " + e.getMessage());
            return false;
        }

        if (updated) {
            if (inputFile.delete() && tempFile.renameTo(inputFile)) {
                return true;
            } else {
                System.out.println("Could not replace the original file.");
                return false;
            }
        } else {
            tempFile.delete();
            return false;
        }
    }


}
