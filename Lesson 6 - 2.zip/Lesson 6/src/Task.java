public class Task {
    private String taskId;
    private String assignedTo;
    private String description;
    private String deadline;
    private boolean completed;

    public Task(String taskId, String assignedTo, String description, String deadline, boolean completed) {
        this.taskId = taskId;
        this.assignedTo = assignedTo;
        this.description = description;
        this.deadline = deadline;
        this.completed = completed;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public String getDescription() {
        return description;
    }

    public String getDeadline() {
        return deadline;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    @Override
    public String toString() {
        return taskId + "," + assignedTo + "," + description + "," + deadline + "," + completed;
    }
}
